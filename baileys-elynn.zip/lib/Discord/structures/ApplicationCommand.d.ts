/** @module ApplicationCommand */
import Base from "./Base";
import Permission from "./Permission";
import type Guild from "./Guild";
import type ClientApplication from "./ClientApplication";
import type * as Types from "../types/namespaced";
import type Client from "../Client";
import { ApplicationCommandTypes, type InteractionContextTypes, type ApplicationIntegrationTypes, type EntryPointCommandHandlerTypes } from "../Constants";
/** Represents an application command. */
export default class ApplicationCommand<T extends ApplicationCommandTypes = ApplicationCommandTypes> extends Base {
    private _cachedGuild?;
    /** The application this command is for. */
    application?: ClientApplication;
    /** The ID of application this command is for. */
    applicationID: string;
    /** The contexts in which this application command can be used in. */
    contexts: Array<InteractionContextTypes>;
    /** The default permissions for this command. */
    defaultMemberPermissions: Permission | null;
    /** The description of this command. Empty string for non `CHAT_INPUT` commands. */
    description: T extends ApplicationCommandTypes.CHAT_INPUT ? string : "";
    /** A dictionary of [locales](https://discord.com/developers/docs/reference#locales) to localized descriptions. */
    descriptionLocalizations?: Types.Applications.LocaleMap | null;
    /** The description of this application command in the requested locale. */
    descriptionLocalized?: string;
    /** If this command can be used in direct messages (global commands only). */
    dmPermission?: boolean;
    /** The id of the guild this command is in (guild commands only). */
    guildID: string | null;
    /** The handler of this command. Only valid for `PRIMARY_ENTRY_POINT` commands. */
    handler?: EntryPointCommandHandlerTypes;
    /** The installation contexts in which this command is available. */
    integrationTypes: Array<ApplicationIntegrationTypes>;
    /** The name of this command. */
    name: string;
    /** A dictionary of [locales](https://discord.com/developers/docs/reference#locales) to localized names. */
    nameLocalizations?: Types.Applications.LocaleMap | null;
    /** The description of this application command in the requested locale. */
    nameLocalized?: string;
    /** Whether the command is age restricted. */
    nsfw?: boolean;
    /** The options on this command. Only valid for `CHAT_INPUT`. */
    options?: Array<Types.Applications.ApplicationCommandOptions>;
    /** The [type](https://discord.com/developers/docs/interactions/application-commands#application-command-object-application-command-types) of this command. */
    type: T;
    /** Autoincrementing version identifier updated during substantial record changes. */
    version: string;
    constructor(data: Types.Applications.RawApplicationCommand, client: Client);
    /** The guild this command is in (guild commands only). This will throw an error if the guild is not cached. */
    get guild(): Guild | null;
    /**
     * Delete this command.
     */
    delete(): Promise<void>;
    /**
     * Edit this command.
     * @param options The options for editing the command.
     */
    edit(options: Types.Applications.TypeToEdit<T>): Promise<Types.Applications.ApplicationCommandOptionConversion<Types.Applications.TypeToEdit<T>>>;
    /**
     * Edit this command's permissions (guild commands only). This requires a bearer token with the `applications.commands.permissions.update` scope.
     * @param options The options for editing the permissions.
     */
    editGuildCommandPermissions(options: Types.Applications.EditApplicationCommandPermissionsOptions): Promise<Types.Applications.RESTGuildApplicationCommandPermissions>;
    /**
     * Get this command's permissions (guild commands only).
     */
    getGuildPermission(): Promise<Types.Applications.RESTGuildApplicationCommandPermissions>;
    /**
     * Get a mention for this command.
     * @param sub The subcommand group and/or subcommand to include (["subcommand"] or ["subcommand-group", "subcommand"]).
     */
    mention(sub?: [subcommand: string] | [subcommandGroup: string, subcommand: string]): string;
    toJSON(): Types.JSON.JSONApplicationCommand;
}
