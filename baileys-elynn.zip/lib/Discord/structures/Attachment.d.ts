/** @module Attachment */
import Base from "./Base";
import type User from "./User";
import Application from "./Application";
import type * as Types from "../types/namespaced";
import type Client from "../Client";
/** Represents a file attachment. */
export default class Attachment extends Base {
    /** For Clips, the application in the stream, if recognized. */
    application?: Application;
    /** For Clips, when the clip was created. */
    clipCreatedAt?: Date;
    /** For Clips, array of users who were in the stream. */
    clipParticipants?: Array<User>;
    /** The mime type of this attachment. */
    contentType?: string;
    /** The description of this attachment. */
    description?: string;
    /** The duration of the attached audio file, if voice message. */
    durationSecs?: number;
    /** If this attachment is ephemeral. Ephemeral attachments will be removed after a set period of time. */
    ephemeral?: boolean;
    /** The filename of this attachment. */
    filename: string;
    /** The {@link Constants~AttachmentFlags | Attachment Flags } of this image. */
    flags: number;
    /** The height of this attachment, if an image. */
    height?: number;
    /** A proxied url of this attachment. */
    proxyURL: string;
    /** The size of this attachment. */
    size: number;
    /** The title of this attachment. */
    title?: string;
    /** The source url of this attachment. */
    url: string;
    /** Base64 encoded bytearray representing a sampled waveform for voice messages. */
    waveform?: string | null;
    /** The width of this attachment, if an image. */
    width?: number;
    constructor(data: Types.Channels.RawAttachment, client: Client);
    toJSON(): Types.JSON.JSONAttachment;
}
