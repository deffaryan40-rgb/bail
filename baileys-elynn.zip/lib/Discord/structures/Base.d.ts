/** @module Base */
import type * as Types from "../types/namespaced";
import type Client from "../Client";
import { inspect } from "node:util";
/** A base class which most other classes extend. */
export default abstract class Base {
    /** @hidden */
    [inspect.custom]: () => this;
    client: Client;
    id: string;
    constructor(id: string, client: Client);
    static generateID(timestamp?: number | Date): string;
    static getCreatedAt(id: string): Date;
    static getDiscordEpoch(id: string): number;
    protected update(data: unknown): void;
    get createdAt(): Date;
    toJSON(): Types.JSON.JSONBase;
    toString(): string;
}
