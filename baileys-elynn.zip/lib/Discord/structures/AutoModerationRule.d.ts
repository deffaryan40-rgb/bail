/** @module AutoModerationRule */
import Base from "./Base";
import type User from "./User";
import type Guild from "./Guild";
import type * as Types from "../types/namespaced";
import type Client from "../Client";
import type { AutoModerationEventTypes, AutoModerationTriggerTypes } from "../Constants";
/** Represents an auto moderation rule. */
export default class AutoModerationRule extends Base {
    private _cachedGuild?;
    /** The actions that will execute when this rule is triggered. */
    actions: Array<Types.AutoModeration.AutoModerationAction>;
    /** The creator of this rule. */
    creator?: User;
    /** The ID of the creator of this rule. */
    creatorID: string;
    /** If this rule is enabled. */
    enabled: boolean;
    /** The [event type](https://discord.com/developers/docs/resources/auto-moderation#auto-moderation-rule-object-event-types) of this rule. */
    eventType: AutoModerationEventTypes;
    /** The channels that are exempt from this rule. */
    exemptChannels: Array<string>;
    /** The roles that are exempt from this rule. */
    exemptRoles: Array<string>;
    /** The id of the guild this rule is in. */
    guildID: string;
    /** The name of this rule */
    name: string;
    /** The metadata of this rule's trigger.  */
    triggerMetadata: Types.AutoModeration.TriggerMetadata;
    /** This rule's [trigger type](https://discord.com/developers/docs/resources/auto-moderation#auto-moderation-rule-object-trigger-types). */
    triggerType: AutoModerationTriggerTypes;
    constructor(data: Types.AutoModeration.RawAutoModerationRule, client: Client);
    protected update(data: Partial<Types.AutoModeration.RawAutoModerationRule>): void;
    /** The guild this rule is in. This will throw an error if the guild is not cached. */
    get guild(): Guild;
    /**
     * Delete this auto moderation rule.
     * @param reason The reason for deleting this rule.
     */
    deleteAutoModerationRule(reason?: string): Promise<void>;
    /**
     * Edit this auto moderation rule.
     * @param options The options for editing the rule.
     */
    edit(options: Types.AutoModeration.EditAutoModerationRuleOptions): Promise<AutoModerationRule>;
    toJSON(): Types.JSON.JSONAutoModerationRule;
}
