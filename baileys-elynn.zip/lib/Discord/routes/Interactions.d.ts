/** @module REST/Interactions */
import type * as Types from "../types/namespaced";
import type RESTManager from "../rest/RESTManager";
import type Message from "../structures/Message";
/** Various methods for interacting with interactions. Located at {@link Client#rest | Client#rest}{@link RESTManager#interactions | .interactions}. */
export default class Interactions {
    private _manager;
    constructor(manager: RESTManager);
    /**
     * Create a followup message.
     * @param applicationID The ID of the application.
     * @param interactionToken The token of the interaction.
     * @param options The options for creating the followup message.
     * @caching This method **does not** cache its result.
     */
    createFollowupMessage<T extends Types.Channels.AnyTextableChannel | Types.Shared.Uncached>(applicationID: string, interactionToken: string, options: Types.Interactions.InteractionContent): Promise<Message<T>>;
    /**
     * Create an initial interaction response.
     * @param interactionID The ID of the interaction.
     * @param interactionToken The token of the interaction.
     * @param options The options for creating the interaction response.
     * @param withResponse Whether to include the response in the result.
     * @caching This method **does not** cache its result.
     */
    createInteractionResponse(interactionID: string, interactionToken: string, options: Types.Interactions.InteractionResponse, withResponse?: false): Promise<null>;
    createInteractionResponse<CH extends Types.Channels.AnyInteractionChannel | Types.Shared.Uncached = Types.Channels.AnyInteractionChannel | Types.Shared.Uncached>(interactionID: string, interactionToken: string, options: Types.Interactions.InteractionResponse, withResponse: true): Promise<Types.Interactions.InteractionCallbackResponse<CH>>;
    /**
     * Delete a follow-up message.
     * @param applicationID The ID of the application.
     * @param interactionToken The token of the interaction.
     * @param messageID The ID of the message.
     * @caching This method **does not** cache its result.
     */
    deleteFollowupMessage(applicationID: string, interactionToken: string, messageID: string): Promise<void>;
    /**
     * Delete the original interaction response.
     * @param applicationID The ID of the application.
     * @param interactionToken The token of the interaction.
     * @caching This method **does not** cache its result.
     */
    deleteOriginalMessage(applicationID: string, interactionToken: string): Promise<void>;
    /**
     * Edit a followup message.
     * @param applicationID The ID of the application.
     * @param interactionToken The token of the interaction.
     * @param messageID The ID of the message.
     * @param options The options for editing the followup message.
     * @caching This method **does not** cache its result.
     */
    editFollowupMessage<T extends Types.Channels.AnyTextableChannel | Types.Shared.Uncached>(applicationID: string, interactionToken: string, messageID: string, options: Types.Interactions.EditInteractionContent): Promise<Message<T>>;
    /**
     * Edit an original interaction response.
     * @param applicationID The ID of the application.
     * @param interactionToken The token of the interaction.
     * @param options The options for editing the original message.
     * @caching This method **does not** cache its result.
     */
    editOriginalMessage<T extends Types.Channels.AnyTextableChannel | Types.Shared.Uncached>(applicationID: string, interactionToken: string, options: Types.Interactions.EditInteractionContent): Promise<Message<T>>;
    /**
     * Get a followup message.
     * @param applicationID The ID of the application.
     * @param interactionToken The token of the interaction.
     * @param messageID The ID of the message.
     * @caching This method **does not** cache its result.
     */
    getFollowupMessage<T extends Types.Channels.AnyTextableChannel | Types.Shared.Uncached>(applicationID: string, interactionToken: string, messageID: string): Promise<Message<T>>;
    /**
     * Get an original interaction response.
     * @param applicationID The ID of the application.
     * @param interactionToken The token of the interaction.
     * @caching This method **does not** cache its result.
     */
    getOriginalMessage<T extends Types.Channels.AnyTextableChannel | Types.Shared.Uncached>(applicationID: string, interactionToken: string): Promise<Message<T>>;
}
