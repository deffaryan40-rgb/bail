import axios from 'axios';
export default {
  id: 'info-jadwaltv', name: 'Jadwal TV', category: 'Info',
  path: '/api/info/jadwaltv', method: 'GET',
  description: 'Jadwal acara TV hari ini',
  params: [{ name: 'channel', required: true, example: 'sctv', description: 'Nama channel TV (sctv, rcti, trans7, dll)' }],
  handler: async (req, getInput) => {
    const channel = getInput(req, 'channel');
    if (!channel) return { ok: false, status: 400, message: "Parameter 'channel' wajib diisi." };
    try {
      const { data } = await axios.get('https://api.siputzx.my.id/api/info/jadwaltv', { params: { channel }, timeout: 15000 });
      if (!data?.status) return { ok: false, status: 502, message: 'Gagal mengambil jadwal TV.' };
      const arr = Array.isArray(data.data) ? data.data : [];
      const rows = arr.slice(0, 8).map(x =>
        `⏰ ${x.waktu || x.time || ''} — *${x.acara || x.judul || x.title || '-'}*`
      ).join('\n');
      const text = `📺 *Jadwal TV ${channel.toUpperCase()}*\n\n${rows || 'Tidak ada jadwal.'}`;
      return { ok: true, type: 'text', result: text };
    } catch (err) { return { ok: false, status: 500, message: err.message }; }
  },
};
