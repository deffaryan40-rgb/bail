// File: plugins/maker/brat.js

import axios from 'axios';

export default {
  id:          'maker-brat',
  name:        'Brat',
  category:    'Maker',
  path:        '/api/maker/brat',
  method:      'GET',
  description: 'Text-to-image brat meme (auto sticker)',
  asSticker:   true,

  params: [
    {
      name: 'text',
      required: true,
      example: 'ayo scroll fesnuk 😜',
      description: 'Input text',
    }
  ],

  handler: async (req, getInput, res) => {
    const text = getInput(req, 'text');
    if (!text) return { ok: false, status: 400, message: "Parameter 'text' wajib diisi." };

    try {
      const response = await axios.get('https://api.siputzx.my.id/api/m/brat', {
        params: { text },
        timeout: 20000,
        responseType: 'arraybuffer',
        headers: { 'User-Agent': 'Elynn/1.0' },
      });

      const buffer = Buffer.from(response.data);
      if (!buffer || buffer.length < 100) {
        return { ok: false, status: 502, message: 'Upstream tidak mengembalikan gambar.' };
      }

      return { ok: true, type: 'sticker', buffer };
    } catch (err) {
      return { ok: false, status: 500, message: err.message || 'Internal server error.' };
    }
  },
};
