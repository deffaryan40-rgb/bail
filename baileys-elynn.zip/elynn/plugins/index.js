/**
 * ELYNN PLUGINS INDEX
 * ====================
 * Semua plugin tersedia dengan nama pendek & mudah diingat.
 * 
 * IMPORT:
 *   import plugins from 'baileys-elynn/elynn'
 *   const { tiktok, cnbc, ai, yt } = plugins
 * 
 *   // atau manual:
 *   import { tiktok } from 'baileys-elynn/elynn'
 */

// ── AI ─────────────────────────────────────────────────────────────
import _deepseek  from './ai/deepseekr1.js';
import _qwq       from './ai/qwq32b.js';
import _glm       from './ai/glm47flash.js';
import _gpt       from './ai/gptoss120b.js';
import _gita      from './ai/gita.js';

// ── BERITA ─────────────────────────────────────────────────────────
import _cnbc      from './berita/cnbcindonesia.js';
import _cnn       from './berita/cnn.js';
import _kompas    from './berita/kompas.js';
import _antara    from './berita/antara.js';
import _liputan6  from './berita/liputan6.js';
import _merdeka   from './berita/merdeka.js';
import _sindonews from './berita/sindonews.js';
import _tribun    from './berita/tribunnews.js';

// ── DOWNLOADER ─────────────────────────────────────────────────────
import _tiktok    from './downloader/tiktok.js';
import _tiktokhd  from './downloader/tiktokhd.js';
import _twitter   from './downloader/twitter.js';
import _fb        from './downloader/facebook.js';
import _douyin    from './downloader/douyin.js';
import _snack     from './downloader/snackvideo.js';
import _sc        from './downloader/soundcloud.js';
import _ummy      from './downloader/ummy.js';
import _lahelu    from './downloader/lahelu.js';
import _github    from './downloader/github.js';

// ── SEARCH ─────────────────────────────────────────────────────────
import _yt        from './search/youtube.js';
import _brave     from './search/brave.js';
import _ddg       from './search/duckduckgo.js';
import _bimg      from './search/bimg.js';
import _pin       from './search/pinterest.js';
import _scsearch  from './search/soundcloud.js';
import _resep     from './search/resep.js';
import _mcpedl   from './search/mcpedl.js';
import _lahelu2   from './search/lahelu.js';
import _manga     from './search/mangatoon.js';
import _otaku     from './search/otakotaku.js';
import _8font     from './search/8font.js';
import _myinst    from './search/myinstants.js';
import _apple     from './search/applemusic.js';
import _seegore   from './search/seegore.js';

// ── STALK ──────────────────────────────────────────────────────────
import _stalktw   from './stalk/twitter.js';
import _stalktk   from './stalk/tiktok.js';
import _stalkyt   from './stalk/youtube.js';
import _stalkgh   from './stalk/github.js';
import _stalkpin  from './stalk/pinterest.js';
import _stalkth   from './stalk/threads.js';

// ── INFO ───────────────────────────────────────────────────────────
import _cuaca     from './info/cuaca.js';
import _bmkg      from './info/bmkg.js';
import _jadwaltv  from './info/jadwaltv.js';

// ── MAKER ──────────────────────────────────────────────────────────
import _brat      from './maker/brat.js';
import _bratvid   from './maker/bratvid.js';

// ═══════════════════════════════════════════════════════════════════
// COMMAND MAP — semua alias pendek yang bisa dipake di bot
// Format: 'alias': pluginObject
// ═══════════════════════════════════════════════════════════════════
export const commands = {
  // AI
  'ai':         _deepseek,
  'deepseek':   _deepseek,
  'deepseekr1': _deepseek,
  'qwq':        _qwq,
  'qwq32b':     _qwq,
  'glm':        _glm,
  'glm4':       _glm,
  'gpt':        _gpt,
  'gita':       _gita,

  // BERITA
  'cnbc':       _cnbc,
  'cnn':        _cnn,
  'kompas':     _kompas,
  'antara':     _antara,
  'liputan6':   _liputan6,
  'liputan':    _liputan6,
  'merdeka':    _merdeka,
  'sindo':      _sindonews,
  'sindonews':  _sindonews,
  'tribun':     _tribun,
  'tribunnews': _tribun,

  // DOWNLOADER
  'tiktok':     _tiktok,
  'tt':         _tiktok,
  'tth':        _tiktokhd,
  'tiktokhd':   _tiktokhd,
  'twitter':    _twitter,
  'twdl':       _twitter,
  'xdl':        _twitter,
  'fb':         _fb,
  'facebook':   _fb,
  'douyin':     _douyin,
  'dy':         _douyin,
  'snack':      _snack,
  'sc':         _sc,
  'soundcloud': _sc,
  'ummy':       _ummy,
  'lahelu':     _lahelu,
  'gitdl':      _github,

  // SEARCH
  'yt':         _yt,
  'youtube':    _yt,
  'brave':      _brave,
  'ddg':        _ddg,
  'duckduckgo': _ddg,
  'bimg':       _bimg,
  'pin':        _pin,
  'pinterest':  _pin,
  'scsearch':   _scsearch,
  'resep':      _resep,
  'mcpe':       _mcpedl,
  'mcpedl':    _mcpedl,
  'lahelu2':    _lahelu2,
  'manga':      _manga,
  'otaku':      _otaku,
  '8font':      _8font,
  'sfont':      _8font,
  'myinstants': _myinst,
  'apple':      _apple,
  'applemusic': _apple,
  'gore':       _seegore,
  'seegore':    _seegore,

  // STALK
  'stalktwitter': _stalktw,
  'stalkx':       _stalktw,
  'stalktiktok':  _stalktk,
  'stalkyt':      _stalkyt,
  'stalkyoutube': _stalkyt,
  'stalkgithub':  _stalkgh,
  'stalkpin':     _stalkpin,
  'stalkpinterest': _stalkpin,
  'stalkthreads': _stalkth,
  'threads':      _stalkth,

  // INFO
  'cuaca':      _cuaca,
  'bmkg':       _bmkg,
  'jadwaltv':   _jadwaltv,
  'tv':         _jadwaltv,

  // MAKER
  'brat':       _brat,
  'bratvid':    _bratvid,
};

// Named exports untuk import manual
export const ai         = _deepseek;
export const deepseek   = _deepseek;
export const qwq        = _qwq;
export const glm        = _glm;
export const gpt        = _gpt;
export const gita       = _gita;

export const cnbc       = _cnbc;
export const cnn        = _cnn;
export const kompas     = _kompas;
export const antara     = _antara;
export const liputan6   = _liputan6;
export const merdeka    = _merdeka;
export const sindo      = _sindonews;
export const tribun     = _tribun;

export const tiktok     = _tiktok;
export const tiktokhd   = _tiktokhd;
export const twitter    = _twitter;
export const fb         = _fb;
export const douyin     = _douyin;
export const snack      = _snack;
export const soundcloud = _sc;
export const ummy       = _ummy;
export const lahelu     = _lahelu;

export const yt         = _yt;
export const brave      = _brave;
export const ddg        = _ddg;
export const bimg       = _bimg;
export const pin        = _pin;
export const resep      = _resep;
export const mcpedl     = _mcpedl;
export const manga      = _manga;
export const otaku      = _otaku;
export const apple      = _apple;

export const cuaca      = _cuaca;
export const bmkg       = _bmkg;
export const jadwaltv   = _jadwaltv;

export const brat       = _brat;
export const bratvid    = _bratvid;


export const github      = _github;

export const seegore     = _seegore;
export const sfont       = _8font;
export const myinstants  = _myinst;
export const scsearch    = _scsearch;

export const stalktwitter  = _stalktw;
export const stalktiktok   = _stalktk;
export const stalkyt       = _stalkyt;
export const stalkgithub   = _stalkgh;
export const stalkpin      = _stalkpin;
export const stalkthreads  = _stalkth;

export default commands;
