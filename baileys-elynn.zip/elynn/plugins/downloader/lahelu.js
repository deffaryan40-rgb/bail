import axios from 'axios';
export default {
  id: 'dl-lahelu', name: 'Lahelu Downloader', category: 'Downloader',
  path: '/api/d/lahelu', method: 'GET',
  description: 'Download konten Lahelu',
  params: [{ name: 'url', required: true, example: 'https://lahelu.com/post/xxx', description: 'URL post Lahelu' }],
  handler: async (req, getInput) => {
    const url = getInput(req, 'url');
    if (!url) return { ok: false, status: 400, message: "Parameter 'url' wajib diisi." };
    try {
      const { data } = await axios.get('https://api.siputzx.my.id/api/d/lahelu', { params: { url }, timeout: 20000 });
      if (!data?.status) return { ok: false, status: 502, message: 'Gagal mengunduh.' };
      const videoUrl = data.data?.video || data.data?.url;
      const caption = data.data?.title || 'Lahelu';
      if (!videoUrl) return { ok: false, status: 502, message: 'URL video tidak ditemukan.' };
      return { ok: true, type: 'video', url: videoUrl, caption };
    } catch (err) { return { ok: false, status: 500, message: err.message }; }
  },
};
