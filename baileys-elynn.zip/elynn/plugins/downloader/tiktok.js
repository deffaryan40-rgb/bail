import axios from 'axios';
export default {
  id: 'dl-tiktok', name: 'TikTok Downloader', category: 'Downloader',
  path: '/api/d/tiktok', method: 'GET',
  description: 'Download video TikTok tanpa watermark',
  params: [{ name: 'url', required: true, example: 'https://vt.tiktok.com/xxx/', description: 'URL TikTok' }],
  handler: async (req, getInput) => {
    const url = getInput(req, 'url');
    if (!url) return { ok: false, status: 400, message: "Parameter 'url' wajib diisi." };
    try {
      const { data } = await axios.get('https://api.siputzx.my.id/api/d/tiktok', { params: { url }, timeout: 25000 });
      if (!data?.status) return { ok: false, status: 502, message: 'Gagal mengunduh.' };
      const videoUrl = data.data?.play || data.data?.wmplay || data.data?.hdplay;
      const caption = data.data?.title || data.data?.desc || 'TikTok Video';
      if (!videoUrl) return { ok: false, status: 502, message: 'URL video tidak ditemukan.' };
      return { ok: true, type: 'video', url: videoUrl, caption };
    } catch (err) { return { ok: false, status: 500, message: err.message }; }
  },
};
