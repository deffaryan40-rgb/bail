import axios from 'axios';
export default {
  id: 'dl-snackvideo', name: 'SnackVideo Downloader', category: 'Downloader',
  path: '/api/d/snackvideo', method: 'GET',
  description: 'Download video SnackVideo',
  params: [{ name: 'url', required: true, example: 'https://s.snackvideo.com/p/xxx', description: 'URL SnackVideo' }],
  handler: async (req, getInput) => {
    const url = getInput(req, 'url');
    if (!url) return { ok: false, status: 400, message: "Parameter 'url' wajib diisi." };
    try {
      const { data } = await axios.get('https://api.siputzx.my.id/api/d/snackvideo', { params: { url }, timeout: 20000 });
      if (!data?.status) return { ok: false, status: 502, message: 'Gagal mengunduh.' };
      const videoUrl = data.data?.play || data.data?.url;
      const caption = data.data?.title || 'SnackVideo';
      if (!videoUrl) return { ok: false, status: 502, message: 'URL video tidak ditemukan.' };
      return { ok: true, type: 'video', url: videoUrl, caption };
    } catch (err) { return { ok: false, status: 500, message: err.message }; }
  },
};
