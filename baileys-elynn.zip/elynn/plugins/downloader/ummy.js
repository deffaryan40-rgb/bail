import axios from 'axios';
export default {
  id: 'dl-ummy', name: 'Instagram Downloader (Ummy)', category: 'Downloader',
  path: '/api/d/ummy', method: 'GET',
  description: 'Download profil/konten Instagram via ummy',
  params: [{ name: 'url', required: true, example: 'nasaartemis', description: 'Username Instagram' }],
  handler: async (req, getInput) => {
    const url = getInput(req, 'url');
    if (!url) return { ok: false, status: 400, message: "Parameter 'url' wajib diisi." };
    try {
      const { data } = await axios.get('https://api.siputzx.my.id/api/d/ummy', { params: { url }, timeout: 20000 });
      if (!data?.status) return { ok: false, status: 502, message: 'Gagal mengambil data.' };
      const d = data.data || {};
      const text = [
        d.fullName ? `👤 *${d.fullName}*` : '',
        d.username ? `🔖 @${d.username}` : '',
        d.bio ? `📝 ${d.bio}` : '',
        d.followers != null ? `👥 Followers: ${d.followers}` : '',
        d.following != null ? `➡️ Following: ${d.following}` : '',
        d.posts != null ? `📸 Posts: ${d.posts}` : '',
        d.profilePicUrl ? `🖼️ ${d.profilePicUrl}` : '',
      ].filter(Boolean).join('\n');
      return { ok: true, type: 'text', result: text || JSON.stringify(d, null, 2) };
    } catch (err) { return { ok: false, status: 500, message: err.message }; }
  },
};
