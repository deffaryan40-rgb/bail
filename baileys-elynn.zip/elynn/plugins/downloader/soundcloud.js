import axios from 'axios';
export default {
  id: 'dl-soundcloud', name: 'SoundCloud Downloader', category: 'Downloader',
  path: '/api/d/soundcloud', method: 'GET',
  description: 'Download audio SoundCloud',
  params: [{ name: 'url', required: true, example: 'https://soundcloud.com/user/track', description: 'URL SoundCloud' }],
  handler: async (req, getInput) => {
    const url = getInput(req, 'url');
    if (!url) return { ok: false, status: 400, message: "Parameter 'url' wajib diisi." };
    try {
      const { data } = await axios.get('https://api.siputzx.my.id/api/d/soundcloud', { params: { url }, timeout: 20000 });
      if (!data?.status) return { ok: false, status: 502, message: 'Gagal mengunduh.' };
      const audioUrl = data.data?.url || data.data?.audio || data.data?.download;
      const caption = data.data?.title || data.data?.name || 'SoundCloud Audio';
      if (!audioUrl) return { ok: false, status: 502, message: 'URL audio tidak ditemukan.' };
      return { ok: true, type: 'audio', url: audioUrl, caption, mimetype: 'audio/mpeg' };
    } catch (err) { return { ok: false, status: 500, message: err.message }; }
  },
};
