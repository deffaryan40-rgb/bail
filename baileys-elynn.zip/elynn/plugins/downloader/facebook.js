import axios from 'axios';
export default {
  id: 'dl-facebook', name: 'Facebook Downloader', category: 'Downloader',
  path: '/api/d/facebook', method: 'GET',
  description: 'Download video Facebook',
  params: [{ name: 'url', required: true, example: 'https://www.facebook.com/share/r/xxx/', description: 'URL video Facebook' }],
  handler: async (req, getInput) => {
    const url = getInput(req, 'url');
    if (!url) return { ok: false, status: 400, message: "Parameter 'url' wajib diisi." };
    try {
      const { data } = await axios.get('https://api.siputzx.my.id/api/d/facebook', { params: { url }, timeout: 20000 });
      if (!data?.status) return { ok: false, status: 502, message: 'Gagal mengunduh.' };
      const videoUrl = data.data?.sd || data.data?.hd;
      const caption = data.data?.title || 'Facebook Video';
      if (!videoUrl) return { ok: false, status: 502, message: 'URL video tidak ditemukan.' };
      return { ok: true, type: 'video', url: videoUrl, caption };
    } catch (err) { return { ok: false, status: 500, message: err.message }; }
  },
};
