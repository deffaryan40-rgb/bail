import axios from 'axios';
export default {
  id: 'dl-github', name: 'GitHub Downloader', category: 'Downloader',
  path: '/api/d/github', method: 'GET',
  description: 'Download/lihat konten GitHub (repo/gist)',
  params: [{ name: 'url', required: true, example: 'https://gist.github.com/user/xxx', description: 'URL GitHub repo atau gist' }],
  handler: async (req, getInput) => {
    const url = getInput(req, 'url');
    if (!url) return { ok: false, status: 400, message: "Parameter 'url' wajib diisi." };
    try {
      const { data } = await axios.get('https://api.siputzx.my.id/api/d/github', { params: { url }, timeout: 20000 });
      if (!data?.status) return { ok: false, status: 502, message: 'Gagal mengambil data.' };
      const d = data.data || {};
      const text = [
        d.name ? `📁 *${d.name}*` : '',
        d.description ? `📝 ${d.description}` : '',
        d.html_url ? `🔗 ${d.html_url}` : '',
        d.stargazers_count != null ? `⭐ ${d.stargazers_count} stars` : '',
        d.forks_count != null ? `🍴 ${d.forks_count} forks` : '',
        d.language ? `💻 ${d.language}` : '',
      ].filter(Boolean).join('\n');
      return { ok: true, type: 'text', result: text || JSON.stringify(d, null, 2) };
    } catch (err) { return { ok: false, status: 500, message: err.message }; }
  },
};
