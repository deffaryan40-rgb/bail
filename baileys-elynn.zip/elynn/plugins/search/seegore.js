import axios from 'axios';
export default {
  id: 'search-seegore', name: 'Search Seegore', category: 'Search',
  path: '/api/s/seegore', method: 'GET',
  description: 'Cari konten di Seegore [18+/Gore]',
  params: [{ name: 'query', required: true, example: 'accident', description: 'Kata kunci pencarian' }],
  handler: async (req, getInput) => {
    const query = getInput(req, 'query');
    if (!query) return { ok: false, status: 400, message: "Parameter 'query' wajib diisi." };
    try {
      const { data } = await axios.get('https://api.siputzx.my.id/api/s/seegore', { params: { query }, timeout: 15000 });
      if (!data?.status) return { ok: false, status: 502, message: 'Gagal mencari.' };
      const imgUrl = Array.isArray(data.data) ? data.data[0]?.thumbnail || data.data[0]?.url || data.data[0] : data.data?.url;
      if (!imgUrl) return { ok: false, status: 502, message: 'Gambar tidak ditemukan.' };
      const caption = Array.isArray(data.data) ? data.data.slice(0,3).map((x,i)=>`${i+1}. ${x.title||''} - ${x.link||x.url||''}`).join('\n') : '';
      return { ok: true, type: 'image', url: String(imgUrl), caption };
    } catch (err) { return { ok: false, status: 500, message: err.message }; }
  },
};
