import axios from 'axios';
export default {
  id: 'search-duckduckgo', name: 'Search duckduckgo', category: 'Search',
  path: '/api/s/duckduckgo', method: 'GET',
  description: 'Cari konten di duckduckgo',
  params: [{ name: 'query', required: true, example: 'openai', description: 'Kata kunci pencarian' }],
  handler: async (req, getInput) => {
    const q = getInput(req, 'query');
    if (!q) return { ok: false, status: 400, message: "Parameter 'query' wajib diisi." };
    try {
      const { data } = await axios.get('https://api.siputzx.my.id/api/s/duckduckgo', { params: { query: q }, timeout: 15000 });
      if (!data?.status) return { ok: false, status: 502, message: 'Gagal mencari.' };
      const arr = Array.isArray(data.data) ? data.data : (data.data ? [data.data] : []);
      const text = arr.slice(0,5).map((x,i)=>`${i+1}. *${x.title||'-'}*\n   ${x.url||x.link||''}\n   ${x.description||''}`).join('\n\n');
      return { ok: true, type: 'text', result: text || 'Tidak ada hasil.' };
    } catch (err) { return { ok: false, status: 500, message: err.message }; }
  },
};
