import axios from 'axios';
export default {
  id: 'search-applemusic', name: 'Search applemusic', category: 'Search',
  path: '/api/s/applemusic', method: 'GET',
  description: 'Cari konten di applemusic',
  params: [{ name: 'query', required: true, example: 'duka', description: 'Kata kunci pencarian' }],
  handler: async (req, getInput) => {
    const q = getInput(req, 'query');
    if (!q) return { ok: false, status: 400, message: "Parameter 'query' wajib diisi." };
    try {
      const { data } = await axios.get('https://api.siputzx.my.id/api/s/applemusic', { params: { query: q }, timeout: 15000 });
      if (!data?.status) return { ok: false, status: 502, message: 'Gagal mencari.' };
      const arr = Array.isArray(data.data) ? data.data : (data.data ? [data.data] : []);
      const text = arr.slice(0,5).map((x,i)=>`${i+1}. *${x.title||x.name||'-'}*\n   ${x.url||x.link||''}`).join('\n\n');
      return { ok: true, type: 'text', result: text || 'Tidak ada hasil.' };
    } catch (err) { return { ok: false, status: 500, message: err.message }; }
  },
};
