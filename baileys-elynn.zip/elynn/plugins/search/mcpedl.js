import axios from 'axios';
export default {
  id: 'search-mcpedl', name: 'Search mcpedl', category: 'Search',
  path: '/api/s/mcpedl', method: 'GET',
  description: 'Cari konten di mcpedl',
  params: [{ name: 'q', required: true, example: 'shaders', description: 'Kata kunci pencarian' }],
  handler: async (req, getInput) => {
    const q = getInput(req, 'q');
    if (!q) return { ok: false, status: 400, message: "Parameter 'q' wajib diisi." };
    try {
      const { data } = await axios.get('https://api.siputzx.my.id/api/s/mcpedl', { params: { q: q }, timeout: 15000 });
      if (!data?.status) return { ok: false, status: 502, message: 'Gagal mencari.' };
      const arr = Array.isArray(data.data) ? data.data : (data.data ? [data.data] : []);
      const text = arr.slice(0,5).map((x,i)=>`${i+1}. *${x.title||x.name||'-'}*\n   ${x.url||x.link||''}`).join('\n\n');
      return { ok: true, type: 'text', result: text || 'Tidak ada hasil.' };
    } catch (err) { return { ok: false, status: 500, message: err.message }; }
  },
};
