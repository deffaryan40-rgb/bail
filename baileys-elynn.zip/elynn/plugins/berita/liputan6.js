import axios from 'axios';
export default {
  id: 'berita-liputan6', name: 'Berita liputan6', category: 'Berita',
  path: '/api/berita/liputan6', method: 'GET',
  description: 'Ambil berita terbaru dari liputan6',
  params: [],
  handler: async (_req, _getInput) => {
    try {
      const { data } = await axios.get('https://api.siputzx.my.id/api/berita/liputan6', { timeout: 15000 });
      if (!data?.status) return { ok: false, status: 502, message: 'Gagal mengambil berita.' };
      const arr = Array.isArray(data.data) ? data.data : [];
      const text = arr.slice(0, 5).map((item, i) =>
        `${i+1}. *${item.title || item.judul || '-'}*\n   ${item.link || item.url || ''}`
      ).join('\n\n');
      return { ok: true, type: 'text', result: text || 'Tidak ada berita.' };
    } catch (err) { return { ok: false, status: 500, message: err.message }; }
  },
};
