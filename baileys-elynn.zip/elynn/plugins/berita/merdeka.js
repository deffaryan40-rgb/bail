import axios from 'axios';
export default {
  id: 'berita-merdeka', name: 'Berita merdeka', category: 'Berita',
  path: '/api/berita/merdeka', method: 'GET',
  description: 'Ambil berita terbaru dari merdeka',
  params: [],
  handler: async (_req, _getInput) => {
    try {
      const { data } = await axios.get('https://api.siputzx.my.id/api/berita/merdeka', { timeout: 15000 });
      if (!data?.status) return { ok: false, status: 502, message: 'Gagal mengambil berita.' };
      const arr = Array.isArray(data.data) ? data.data : [];
      const text = arr.slice(0, 5).map((item, i) =>
        `${i+1}. *${item.title || item.judul || '-'}*\n   ${item.link || item.url || ''}`
      ).join('\n\n');
      return { ok: true, type: 'text', result: text || 'Tidak ada berita.' };
    } catch (err) { return { ok: false, status: 500, message: err.message }; }
  },
};
