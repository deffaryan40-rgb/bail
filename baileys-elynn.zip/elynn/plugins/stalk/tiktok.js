import axios from 'axios';
export default {
  id: 'stalk-tiktok', name: 'Stalk TikTok', category: 'Stalk',
  path: '/api/stalk/tiktok', method: 'GET',
  description: 'Lihat profil TikTok',
  params: [{ name: 'user', required: true, example: 'charlidamelio', description: 'Username TikTok' }],
  handler: async (req, getInput) => {
    const q = getInput(req, 'user');
    if (!q) return { ok: false, status: 400, message: "Parameter 'user' wajib diisi." };
    try {
      const { data } = await axios.get('https://api.siputzx.my.id/api/stalk/tiktok', { params: { user: q }, timeout: 15000 });
      if (!data?.status) return { ok: false, status: 502, message: 'Gagal mengambil profil TikTok.' };
      const d = data.data || {};
      const text = [
        d.nickname ? `👤 *${d.nickname}*` : '',
        d.uniqueId ? `🔖 @${d.uniqueId}` : '',
        d.signature ? `📝 ${d.signature}` : '',
        d.followerCount != null ? `👥 Followers: ${Number(d.followerCount).toLocaleString()}` : '',
        d.followingCount != null ? `➡️ Following: ${Number(d.followingCount).toLocaleString()}` : '',
        d.heartCount != null ? `❤️ Likes: ${Number(d.heartCount).toLocaleString()}` : '',
        d.videoCount != null ? `🎬 Videos: ${Number(d.videoCount).toLocaleString()}` : '',
        d.verified ? '✅ Verified' : '',
      ].filter(Boolean).join('\n');
      return { ok: true, type: 'text', result: text || 'Data tidak tersedia.' };
    } catch (err) { return { ok: false, status: 500, message: err.message }; }
  },
};
