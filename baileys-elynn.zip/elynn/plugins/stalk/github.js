import axios from 'axios';
export default {
  id: 'stalk-github', name: 'Stalk github', category: 'Stalk',
  path: '/api/stalk/github', method: 'GET',
  description: 'Lihat profil github',
  params: [{ name: 'user', required: true, example: 'octocat', description: 'Username GitHub' }],
  handler: async (req, getInput) => {
    const q = getInput(req, 'user');
    if (!q) return { ok: false, status: 400, message: "Parameter 'user' wajib diisi." };
    try {
      const { data } = await axios.get('https://api.siputzx.my.id/api/stalk/github', { params: { user: q }, timeout: 15000 });
      if (!data?.status) return { ok: false, status: 502, message: 'Gagal mengambil profil.' };
      const d = data.data || {};
      const text = [
        d.name ? `👤 *${d.name}*` : '',
        d.login ? `🔖 @${d.login}` : '',
        d.bio ? `📝 ${d.bio}` : '',
        d.company ? `🏢 ${d.company}` : '',
        d.location ? `📍 ${d.location}` : '',
        d.public_repos != null ? `📦 Repos: ${d.public_repos}` : '',
        d.followers != null ? `👥 Followers: ${d.followers}` : '',
        d.following != null ? `➡️ Following: ${d.following}` : '',
        d.html_url ? `🔗 ${d.html_url}` : '',
      ].filter(Boolean).join('\n');
      return { ok: true, type: 'text', result: text || 'Data tidak tersedia.' };
    } catch (err) { return { ok: false, status: 500, message: err.message }; }
  },
};
