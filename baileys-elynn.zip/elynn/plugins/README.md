# Elynn Plugins

Plugin aktif:

| Key       | Path                   | Desc                   | Output   |
|-----------|------------------------|------------------------|----------|
| `brat`    | `maker/brat.js`        | Brat meme text-to-img  | sticker  |
| `bratvid` | `maker/bratvid.js`     | Brat meme text-to-vid  | sticker  |

## Usage di bot

```js
import { plugins } from 'elynn-baileys'

// Brat → kirim sebagai stiker
const res = await plugins.brat({ text: 'teks lo' })
if (res.ok) {
  await sock.sendMessage(jid, {
    sticker: { url: res.result }
  })
}
```

Semua plugin brat return `{ ok, type: 'sticker', result: <url> }`.
